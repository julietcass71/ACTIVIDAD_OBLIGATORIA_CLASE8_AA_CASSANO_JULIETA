from setuptools import find_packages, setup

setup(
    name='src',
    packages=find_packages(),
    version='0.1.0',
    description='Análisis de segmentación de clientes mediante el algoritmo K-Means, aplicando los conceptos de inercia, coeficiente de silhouette y elección del número óptimo de clusters.',
    author='Nancy Julieta Cassano',
    license='MIT',
)
